from models.regression.adv_efficientnet_late.model import Model  # pyflakes.ignore
