"""A pytorch module (and function) to reverse gradients."""
from .module import RevGrad  # noqa: F401
from .version import __version__  # noqa: F401
