from models.segmentation.unet_pre_trained_rotation.model import Model  # pyflakes.ignore
