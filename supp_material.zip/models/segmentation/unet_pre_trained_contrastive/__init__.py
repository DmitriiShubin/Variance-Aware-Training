from models.segmentation.unet_pre_trained_contrastive.model import Model  # pyflakes.ignore
